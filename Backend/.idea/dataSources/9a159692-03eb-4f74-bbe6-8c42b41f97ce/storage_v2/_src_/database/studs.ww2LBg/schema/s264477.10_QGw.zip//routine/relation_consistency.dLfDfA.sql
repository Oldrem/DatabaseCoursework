create function relation_consistency() returns trigger
    language plpgsql
as
$$
DECLARE
tmp integer;
BEGIN
IF (NEW.COLONY1_ID > NEW.COLONY2_ID) THEN
	Tmp := NEW.COLONY1_ID;
	NEW.COLONY1_ID := NEW.COLONY2_ID;
	NEW.COLONY2_ID := tmp;
	END IF;
RETURN NEW;
END;
$$;

alter function relation_consistency() owner to s264477;

