create function transaction_storage_update() returns trigger
    language plpgsql
as
$$
DECLARE
place STORED_RESOURCE;
room_name text;
res text;
new_amount integer;
BEGIN
	SELECT * INTO place FROM STORED_RESOURCE
WHERE RESOURCE_ID=NEW.RESOURCE_ID AND ROOM_ID=NEW.ROOM_ID;

	SELECT NAME INTO room_name FROM ROOM
WHERE ROOM_ID=NEW.ROOM_ID;

	SELECT NAME INTO res FROM RESOURCE
WHERE RESOURCE_ID=NEW.RESOURCE_ID;

IF (place.AMOUNT IS NULL) THEN
		new_amount := NEW.AMOUNT;
	ELSE
		new_amount := place.AMOUNT + NEW.AMOUNT;
END IF;

	IF (new_amount < 0) THEN
RAISE EXCEPTION 'Невозможно произвести транзакцию - не хватает ресурса % в комнате %', res, room_name;
	END IF;

	IF (place IS NULL) THEN
		INSERT INTO STORED_RESOURCE (RESOURCE_ID, ROOM_ID, AMOUNT)
VALUES (NEW.RESOURCE_ID, NEW.ROOM_ID, new_amount);
	ELSE
UPDATE STORED_RESOURCE
SET AMOUNT = new_amount
WHERE RESOURCE_ID=NEW.RESOURCE_ID AND ROOM_ID=NEW.ROOM_ID;
END IF;
RETURN NEW;
END;
$$;

alter function transaction_storage_update() owner to s264477;

