create function frobidden_resource_storage() returns trigger
    language plpgsql
as
$$
DECLARE
	res RESOURCE;
	room ROOM;
	room_type ROOM_TYPE;
BEGIN
	SELECT * INTO res FROM RESOURCE WHERE RESOURCE_ID=NEW.RESOURCE_ID;
	SELECT * INTO room FROM ROOM WHERE ROOM_ID=NEW.ROOM_ID;
	SELECT * INTO room_type FROM ROOM_TYPE
WHERE ROOM_TYPE_ID=room.ROOM_TYPE_ID;

IF (res.IS_FORBIDDEN AND room_type.access_level <> 'professional') THEN
RAISE EXCEPTION 'Ресурс % является запретным, и его невозможно хранить в комнате %, так как её уровень доступа ниже professional', res.NAME, room.NAME;
	END IF;
RETURN NEW;
END;
$$;

alter function frobidden_resource_storage() owner to s264477;

